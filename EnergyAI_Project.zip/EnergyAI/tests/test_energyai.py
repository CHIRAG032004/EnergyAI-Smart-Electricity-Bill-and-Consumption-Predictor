"""Smoke tests: run with  python -m unittest discover -s tests -v"""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import energy_predictor as ep
import server

ep.DB = os.path.join(tempfile.mkdtemp(), "test.db")   # never touch the real database
CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "demo_monthly_bills.csv")


class T(unittest.TestCase):
    def test_bill_slabs(self):
        self.assertEqual(ep.bill(100), round((350 + 50) * 1.05, 2))
        self.assertEqual(ep.bill(400), round((350 + 1000 + 700 + 50) * 1.05, 2))

    def test_upload_monthly(self):
        kind, rows = server.parse(open(CSV, encoding="utf-8").read())
        self.assertEqual(kind, "monthly"); self.assertEqual(len(rows), 30)
        ep.seed(); server.store(kind, rows)
        r = server.report_monthly()
        self.assertEqual(r["months"], 30); self.assertEqual(len(r["fc"]), 6)
        self.assertLess(r["mape"], 5)

    def test_seeded_anomalies(self):
        ep.seed(True)
        an, _ = ep.daily()
        self.assertEqual(sum(a["flag"] for a in an), 3)

    def test_bad_file(self):
        with self.assertRaises(ValueError): server.parse("")
        with self.assertRaises(ValueError): server.parse("foo,bar\n1,2\n")


if __name__ == "__main__":
    unittest.main()
